# Landing Page Project

interactive and functionality multi-section landing page using the javascript 


##  project files Hierarchy
css
- styles.css    
index.html
js
- app.js
README.md

## usage 

There a  navigation bar where the user can go to each section on page  by click on the name of it.

When user click on navigation item it will scroll to the appropriate section rather than giving you the default jump.

When user scroll to each section it will highlight section in the screen view. 



## Development

    NAV-Menu
I stared by add set the global variables that i think it will not change and i will need it later,
then i made a for loop to  make list items and append them to the unordered list and append anchor element to the list 
and used the data-Nav attribute  to create the text inside anchor element and the value of each section id attribute to create the value of anchor’s href attribute in addition to symbol #, then i create i used DocumentFragment and append all Nav-items to it to make the page more 
performanced.
        Highlight section on screen View

Then, i make option variable  and callback  i made it to take entries  and i made it into an array so i can iterate with forEach and set my 
conditions to determinate if  entry is Intersecting or not and set attribute to section if it is then, i create the IntersectionObserver 
API and drag options and callback into it

            Scroll to section on link click
I start this part using querySelectorAll to get all anchor elements i store them into arry also to iterate to all of them once 
i used arrow function cause to make addEventListener to Listen to user click  also i make another function with parameter so i can use  preventDefault to make the move smooth rather than giving you the default jump and for last thing i use scrollIntoView method and 
set behavior  of  transition animation  smooth to all href attribute .

                CSS
i also make a little bit changes into background color  and Nav bar background color  and  more little changes


## resources and references
here some MDN docs i used
https://developer.mozilla.org/en-US/docs/Learn/HTML/Howto/Use_data_attributes
https://developer.mozilla.org/en-US/docs/Web/API/DocumentFragment
https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API  
** i watched also some  tutorial to use Intersection Observer API
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Arrow_functions
https://developer.mozilla.org/en-US/docs/Web/API/Event/preventDefault
https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView


##
at the end i hope my u like my project and give some tips to get better 


















