/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/
/**
 * Define Global Variables
 * 
*/

const myFrag = document.createDocumentFragment(); 
const myList = document.getElementById('navbar__list');
const sections = document.querySelectorAll('section');
const myNav = document.getElementsByClassName('navbar__menu');


 // End Global Variables

/**
 *   build the nav
*/

// loop over section to use data for 'a' element 
for (let section of sections){
    dataSection = section.getAttribute('data-nav');
    specificSection = section.getAttribute('id');
    //also loop to create li elemnt 
    const list = document.createElement('li');
        //create 'a' element and add href class and 'menu__link' like the name was in css file 
        const aTag = document.createElement('a');
        aTag.href = `#${specificSection}`;
        aTag.className = "menu__link";
        //add text in side it 
        aTag.innerText = `${dataSection}`;
        //append 'a' element to 'li' && append 'li' to unordered list 'ul' 
        list.appendChild(aTag);
    myList.appendChild(list);
    
    
}
//append all items in our nav to DocumentFragment to get more performance 
function appendToNav (){
    myNav.appendChild(myList);
        myFrag.appendChild(myNav);
            document.body.appendChild(myFrag);
}


/**
 * scroll Atavie section
 */

//create options object
const options = {
    root : null,
    rootMargin: '0px',
    threshold: 0.7
}
// our callback 
const callback =(entries) => {
    //for each element "section" as entry and iterate over this entries
    entries.forEach(entry => {
        if (entry.isIntersecting){
            // Add class 'active' to section when near top of viewport
            entry.target.classList.add('your-active-class');
        }
        // and remove if not 
        else{
            entry.target.classList.remove('your-active-class');

        }
    })
};

// and we create our Intersection Observer API then add our callBack and options to it 

let secObserver = new IntersectionObserver (callback,options);

// and then  register which elements we are observing 
sections.forEach(sections=> {
    secObserver.observe(sections);
});
//done 




// Scroll to section on link click
//use querySelector to get all 'a' element && stor them in arry so we can add eventListener to all in once with forEach
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    //event Listener activate on click
    anchor.addEventListener('click', function (e) {
        // use prevent to make the move smooth rather than giving you the default jump.
            e.preventDefault();
        // Scroll to anchor ID using scrollTO event
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});



